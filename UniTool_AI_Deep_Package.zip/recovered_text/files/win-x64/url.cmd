@echo off
data\lib\win-x64\curl.exe -s -k "https://drlinhbypass.info/update/unlockramdisk.php"