#!/usr/bin/env python3
"""
usbliter8 orchestrator — unified Mac-side tool for the usbliter8 A12/A13 exploit workflow.

Automates: RP2350 serial monitoring → PWND DFU detection → payload loading → PongoOS communication.

Usage:
    orchestrator.py monitor [--port /dev/tty.usbmodemXXXX]
    orchestrator.py info
    orchestrator.py demote
    orchestrator.py boot <image>
    orchestrator.py pongo [--kpf <kpf> --ramdisk <ramdisk> --overlay <overlay>]
    orchestrator.py auto <image> [--port /dev/tty.usbmodemXXXX]
"""

import argparse
import struct
import sys
import time
import re
from pathlib import Path

try:
    import usb.core
    import usb.util
except ImportError:
    print("pyusb required: pip install pyusb")
    sys.exit(1)

APPLE_VID       = 0x05AC
DFU_PID         = 0x1227
PONGO_PID       = 0x4141

DFU_DNLOAD      = 1
DFU_ABORT       = 6
CUSTOM_DEMOTE   = 7
CUSTOM_BOOT     = 8
CUSTOM_AES_GID  = 9
CUSTOM_TEST     = 10
CUSTOM_READ     = 11
CUSTOM_WRITE    = 12

TRANSFER_SIZE   = 0x800
MAX_READ_CHUNK  = 0x800

PONGO_CMD_RESET     = 4
PONGO_CMD_SEND      = 3
PONGO_CMD_POLL      = 2
PONGO_CMD_RECV      = 1
PONGO_UPLOAD_SIZE   = 1


def parse_dfu_serial(serial):
    """Parse DFU serial number string into dict of fields."""
    fields = {}
    for match in re.finditer(r'(\w+):(\[?[\w\.\-]+\]?)', serial):
        fields[match.group(1)] = match.group(2)
    fields['pwnd'] = 'PWND' in serial
    return fields


def find_dfu_device(timeout=0):
    """Find Apple DFU device, optionally waiting up to timeout seconds."""
    deadline = time.time() + timeout if timeout else 0
    while True:
        dev = usb.core.find(idVendor=APPLE_VID, idProduct=DFU_PID)
        if dev:
            return dev
        if not timeout or time.time() > deadline:
            return None
        time.sleep(0.5)


def find_pongo_device(timeout=30):
    """Find PongoOS USB device (05AC:4141)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        dev = usb.core.find(idVendor=APPLE_VID, idProduct=PONGO_PID)
        if dev:
            return dev
        time.sleep(0.5)
    return None


def get_serial(dev):
    """Read USB serial number string."""
    try:
        return dev.serial_number
    except Exception:
        return ""


def require_pwnd(dev):
    """Ensure device is in PWND DFU mode."""
    serial = get_serial(dev)
    if "PWND:[" not in serial:
        print(f"ERROR: device is not in PWND DFU mode")
        print(f"  serial: {serial}")
        sys.exit(1)
    return serial


def _addr_parts(addr):
    high16 = (addr >> 32) & 0xFFFF
    wValue = (addr >> 16) & 0xFFFF
    wIndex = addr & 0xFFFF
    return high16, wValue, wIndex

def _set_addr_high(dev, high16):
    dev.ctrl_transfer(0x21, CUSTOM_WRITE, 0xFFFF, 0xFFFF,
                      struct.pack("<H", high16), 1000)

def mem_read(dev, addr, size):
    result = bytearray()
    high16, _, _ = _addr_parts(addr)
    _set_addr_high(dev, high16)
    offset = 0
    while offset < size:
        chunk = min(MAX_READ_CHUNK, size - offset)
        cur = addr + offset
        cur_high = (cur >> 32) & 0xFFFF
        if cur_high != high16:
            high16 = cur_high
            _set_addr_high(dev, high16)
        _, wV, wI = _addr_parts(cur)
        data = dev.ctrl_transfer(0xA1, CUSTOM_READ, wV, wI, chunk, 5000)
        result.extend(bytes(data))
        offset += len(data)
        if len(data) < chunk:
            break
    return bytes(result)

def mem_write(dev, addr, data):
    high16, _, _ = _addr_parts(addr)
    _set_addr_high(dev, high16)
    offset = 0
    while offset < len(data):
        chunk = min(MAX_READ_CHUNK, len(data) - offset)
        cur = addr + offset
        cur_high = (cur >> 32) & 0xFFFF
        if cur_high != high16:
            high16 = cur_high
            _set_addr_high(dev, high16)
        _, wV, wI = _addr_parts(cur)
        dev.ctrl_transfer(0x21, CUSTOM_WRITE, wV, wI, data[offset:offset+chunk], 5000)
        offset += chunk
    return offset

def hexdump(data, base_addr=0):
    for i in range(0, len(data), 16):
        row = data[i:i+16]
        hx = " ".join(f"{b:02x}" for b in row)
        asc = "".join(chr(b) if 0x20 <= b < 0x7f else "." for b in row)
        print(f"{base_addr+i:016x}  {hx:<48s}  |{asc}|")


def dfu_download(dev, data):
    """Send data to device via DFU DNLOAD protocol."""
    offset = 0
    left = len(data)
    while left:
        chunk = min(TRANSFER_SIZE, left)
        dev.ctrl_transfer(0x21, DFU_DNLOAD, 0, 0, data[offset:offset + chunk], 5000)
        offset += chunk
        left -= chunk
        print(f"\r  sent 0x{offset:x} / 0x{len(data):x} bytes", end="", flush=True)
    print()
    dev.ctrl_transfer(0x21, DFU_DNLOAD, 0, 0, None, 1000)


# --- Commands ---

def cmd_info(args):
    """Show device information."""
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1

    serial = get_serial(dev)
    fields = parse_dfu_serial(serial)

    print(f"Raw serial: {serial}")
    print()
    print(f"  CPID:  {fields.get('CPID', '?')}")
    print(f"  CPRV:  {fields.get('CPRV', '?')}")
    print(f"  CPFM:  {fields.get('CPFM', '?')}")
    print(f"  SCEP:  {fields.get('SCEP', '?')}")
    print(f"  BDID:  {fields.get('BDID', '?')}")
    print(f"  ECID:  {fields.get('ECID', '?')}")
    print(f"  IBFL:  {fields.get('IBFL', '?')}")
    print(f"  SRTG:  {fields.get('SRTG', '?')}")
    print(f"  PWND:  {'YES' if fields.get('pwnd') else 'NO'}")

    cpid = fields.get('CPID', '')
    chip_names = {'8020': 'A12', '8030': 'A13', '8006': 'S4/S5'}
    if cpid in chip_names:
        print(f"  Chip:  {chip_names[cpid]} (T{cpid})")
    return 0


def cmd_demote(args):
    """Demote production mode."""
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1

    require_pwnd(dev)
    print("Sending CUSTOM_DEMOTE...")
    dev.ctrl_transfer(0x21, CUSTOM_DEMOTE, 0, 0, None, 1000)
    print("Done. Device demoted (temporary until reboot).")
    return 0


def cmd_boot(args):
    """Boot a raw iBoot or PongoOS image."""
    image_path = Path(args.image)
    if not image_path.exists():
        print(f"File not found: {image_path}")
        return 1

    data = image_path.read_bytes()
    print(f"Image: {image_path.name} ({len(data)} bytes)")

    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1

    require_pwnd(dev)

    print("Sending image via DFU DNLOAD...")
    dfu_download(dev, data)

    print("Sending CUSTOM_BOOT...")
    dev.ctrl_transfer(0x21, CUSTOM_BOOT, 0, 0, None, 1000)

    print("Sending DFU_ABORT...")
    try:
        dev.ctrl_transfer(0x21, DFU_ABORT, 0, 0, None, 1000)
    except usb.core.USBError:
        pass

    print("Image sent and boot triggered.")
    return 0


def cmd_monitor(args):
    """Monitor RP2350 serial port for exploit status."""
    try:
        import serial
    except ImportError:
        print("pyserial required: pip install pyserial")
        return 1

    port = args.port
    if not port:
        import glob
        candidates = glob.glob("/dev/tty.usbmodem*") + glob.glob("/dev/cu.usbmodem*")
        if not candidates:
            print("No RP2350 serial port found. Specify with --port")
            return 1
        port = candidates[0]

    print(f"Monitoring {port} for RP2350 output...")
    print("(Plug iPhone into RP2350 in DFU mode)")
    print()

    try:
        ser = serial.Serial(port, 115200, timeout=1)
    except serial.SerialException as e:
        print(f"Cannot open {port}: {e}")
        return 1

    success = False
    try:
        while True:
            line = ser.readline().decode('utf-8', errors='replace').strip()
            if line:
                print(f"  [RP2350] {line}")
                if "exploit SUCCESS" in line:
                    success = True
                    print()
                    print("=== EXPLOIT SUCCEEDED ===")
                    print("Swap cable to Mac now.")
                    break
                elif "exploit FAILED" in line or "fatal failure" in line:
                    print()
                    print("=== EXPLOIT FAILED ===")
                    print("Reset RP2350 and try again.")
                    return 1
    except KeyboardInterrupt:
        pass
    finally:
        ser.close()

    if not success:
        return 1

    print()
    print("Waiting for PWND DFU device on Mac USB...")
    dev = find_dfu_device(timeout=30)
    if not dev:
        print("Timeout: no DFU device appeared. Did you swap the cable?")
        return 1

    serial_str = get_serial(dev)
    if "PWND:[" not in serial_str:
        print(f"Device found but NOT pwned: {serial_str}")
        return 1

    fields = parse_dfu_serial(serial_str)
    print(f"PWND DFU device detected! CPID:{fields.get('CPID', '?')} ECID:{fields.get('ECID', '?')}")
    print("Ready for commands (demote, boot, pongo).")
    return 0


def cmd_pongo(args):
    """Send payloads to PongoOS and boot."""
    print("Waiting for PongoOS USB device (05AC:4141)...")
    dev = find_pongo_device(timeout=30)
    if not dev:
        print("PongoOS device not found")
        return 1

    print("Found PongoOS device!")
    dev.set_configuration()

    def pongo_cmd(command):
        if command is None:
            return _pongo_recv(dev)
        print(f"  pongo> {command}")
        cmd_bytes = (command + "\n").encode()
        dev.ctrl_transfer(0x21, PONGO_CMD_RESET, 1, 0, None, 1000)
        dev.ctrl_transfer(0x21, PONGO_CMD_SEND, 0, 0, cmd_bytes, 1000)
        return _pongo_recv(dev)

    def _pongo_recv(dev):
        output = b""
        in_progress = 1
        while in_progress:
            try:
                status = dev.ctrl_transfer(0xa1, PONGO_CMD_POLL, 0, 0, 1, 1000)
                in_progress = status[0] if status else 0
                data = dev.ctrl_transfer(0xa1, PONGO_CMD_RECV, 0, 0, 0x1000, 1000)
                if data:
                    output += bytes(data)
            except usb.core.USBError:
                break
        if output:
            print(output.decode('utf-8', errors='replace'), end="")
        return output

    def pongo_upload(data):
        size_bytes = struct.pack("<I", len(data))
        dev.ctrl_transfer(0x21, PONGO_UPLOAD_SIZE, 0, 0, size_bytes, 1000)
        endpoint = dev[0][(0, 0)][1]
        offset = 0
        while offset < len(data):
            chunk = min(0x10000, len(data) - offset)
            endpoint.write(data[offset:offset + chunk], timeout=10000)
            offset += chunk
            print(f"\r  uploaded 0x{offset:x} / 0x{len(data):x}", end="", flush=True)
        print()

    pongo_cmd(None)
    pongo_cmd("fuse lock")
    pongo_cmd("sep auto")

    if args.kpf:
        kpf_data = Path(args.kpf).read_bytes()
        print(f"Uploading KPF ({len(kpf_data)} bytes)...")
        pongo_upload(kpf_data)
        pongo_cmd("modload")

    if args.ramdisk:
        rd_data = Path(args.ramdisk).read_bytes()
        print(f"Uploading ramdisk ({len(rd_data)} bytes)...")
        pongo_upload(rd_data)
        pongo_cmd("ramdisk")

    if args.overlay:
        ov_data = Path(args.overlay).read_bytes()
        print(f"Uploading overlay ({len(ov_data)} bytes)...")
        pongo_upload(ov_data)
        pongo_cmd("overlay")

    if args.xargs:
        pongo_cmd(f"xargs {args.xargs}")

    if not args.no_boot:
        pongo_cmd("bootx")
        print("Kernel boot triggered!")

    return 0


def cmd_test(args):
    """Test custom handler protocol."""
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1
    require_pwnd(dev)
    result = dev.ctrl_transfer(0xA1, CUSTOM_TEST, 0, 0, 64, 1000)
    text = bytes(result).split(b'\x00')[0].decode('ascii', errors='replace')
    if text == "usbliter8":
        print("protocol OK")
    else:
        print(f"protocol FAIL (got: {text!r})")
    return 0


def cmd_read(args):
    """Read device memory."""
    addr = int(args.addr, 0)
    size = int(args.size, 0)
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1
    require_pwnd(dev)
    data = mem_read(dev, addr, size)
    hexdump(data, addr)
    return 0


def cmd_write(args):
    """Write device memory."""
    addr = int(args.addr, 0)
    data = bytes.fromhex(args.data.replace(" ", ""))
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1
    require_pwnd(dev)
    written = mem_write(dev, addr, data)
    print(f"Wrote {written} bytes to 0x{addr:x}")
    return 0


def cmd_dump(args):
    """Dump memory region to file."""
    regions = {
        'securerom': (0x100000000, 0x30000,  'securerom_t8030.bin'),
        'sram':      (0x19C000000, 0x40000,  'sram_dump.bin'),
        'sram_full': (0x19C000000, 0x400000, 'sram_full.bin'),
    }
    dev = find_dfu_device()
    if not dev:
        print("No DFU device found")
        return 1
    require_pwnd(dev)

    if args.region in regions:
        addr, size, outfile = regions[args.region]
    else:
        addr = int(args.region, 0)
        size = int(args.size, 0) if args.size else 0x1000
        outfile = f"dump_{addr:x}.bin"

    outfile = args.output or outfile
    print(f"Dumping 0x{addr:x} + 0x{size:x} ({size} bytes)...")

    result = bytearray()
    for off in range(0, size, MAX_READ_CHUNK):
        cur = min(MAX_READ_CHUNK, size - off)
        chunk = mem_read(dev, addr + off, cur)
        result.extend(chunk)
        pct = (off + len(chunk)) * 100 // size
        print(f"\r  [{pct:3d}%] 0x{off+len(chunk):x} / 0x{size:x}", end="", flush=True)
    print()

    Path(outfile).write_bytes(bytes(result))
    print(f"Saved to {outfile} ({len(result)} bytes)")
    return 0


def cmd_auto(args):
    """Full automated flow: monitor RP2350 → detect PWND → boot image → (optional) PongoOS."""
    ret = cmd_monitor(args)
    if ret != 0:
        return ret

    print()
    args_boot = argparse.Namespace(image=args.image)
    return cmd_boot(args_boot)


def main():
    parser = argparse.ArgumentParser(
        description="usbliter8 orchestrator — unified exploit workflow tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s info                          Show DFU device info
  %(prog)s demote                        Demote production mode
  %(prog)s boot iBoot.raw                Boot unsigned iBoot image
  %(prog)s monitor --port /dev/tty.usbmodem1101
  %(prog)s auto Pongo.bin --port /dev/tty.usbmodem1101
  %(prog)s pongo --kpf kpf.bin --ramdisk ramdisk.dmg --overlay binpack.dmg
"""
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="show DFU device info")
    sub.add_parser("test", help="verify custom handler protocol")
    sub.add_parser("demote", help="demote production mode")

    boot_p = sub.add_parser("boot", help="boot raw image (iBoot/PongoOS)")
    boot_p.add_argument("image", help="path to raw image file")

    mon_p = sub.add_parser("monitor", help="monitor RP2350 serial port")
    mon_p.add_argument("--port", help="serial port path (auto-detect if omitted)")

    p = sub.add_parser("read", help="read device memory")
    p.add_argument("addr", help="hex address")
    p.add_argument("size", help="bytes to read (hex)")

    p = sub.add_parser("write", help="write device memory")
    p.add_argument("addr", help="hex address")
    p.add_argument("data", help="hex bytes")

    p = sub.add_parser("dump", help="dump region to file (securerom|sram|0xADDR)")
    p.add_argument("region", help="securerom | sram | sram_full | hex addr")
    p.add_argument("size", nargs="?", help="size for custom addr")
    p.add_argument("-o", "--output", help="output file")

    auto_p = sub.add_parser("auto", help="full automated flow: monitor → boot")
    auto_p.add_argument("image", help="path to image to boot after exploit")
    auto_p.add_argument("--port", help="RP2350 serial port")

    pongo_p = sub.add_parser("pongo", help="send payloads to PongoOS")
    pongo_p.add_argument("--kpf", help="kernel patchfinder module")
    pongo_p.add_argument("--ramdisk", help="ramdisk DMG")
    pongo_p.add_argument("--overlay", help="overlay/binpack DMG")
    pongo_p.add_argument("--xargs", help="XNU boot arguments")
    pongo_p.add_argument("--no-boot", action="store_true", help="don't send bootx")

    args = parser.parse_args()

    commands = {
        "info": cmd_info,
        "test": cmd_test,
        "demote": cmd_demote,
        "boot": cmd_boot,
        "read": cmd_read,
        "write": cmd_write,
        "dump": cmd_dump,
        "monitor": cmd_monitor,
        "auto": cmd_auto,
        "pongo": cmd_pongo,
    }

    if not args.command:
        parser.print_help()
        return 1

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
