Rebuild the application from recovered runtime behavior only.

Steps:
1. Read `PROJECT_SUMMARY.md`.
2. Inspect `recovered_text/files/win-x64/`.
3. Recreate a `src/` tree module by module.
4. Preserve the CLI, server routes, adapter behavior, and target discovery flow.
5. Stop and document any unverified behavior instead of guessing.
