# Component Map

## Launcher
- `files/win-x64/index.js`
  - Parses `-p/--port`
  - Handles `--version` and `--help`
  - Creates the proxy server

## Proxy server
- `files/win-x64/server.js`
  - Express HTTP server
  - WebSocket server
  - `/json`, `/json/list`, `/refresh` style endpoints

## Device adapter layer
- `files/win-x64/adapters/adapter.js`
- `files/win-x64/adapters/adapterCollection.js`
- `files/win-x64/adapters/iosAdapter.js`

## Protocol translation
- `files/win-x64/protocols/protocol.js`
- `files/win-x64/protocols/target.js`
- `files/win-x64/protocols/ios/*.js`

## User-facing strings
- `lang.json`
  - Localization / UI messages
  - Device-state prompts and action labels

## Build system
- `files/gulpfile.js`
- `files/tsconfig.json`
- `files/package.json`
