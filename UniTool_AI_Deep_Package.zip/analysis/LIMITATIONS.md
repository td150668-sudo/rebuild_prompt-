# Limitations

- Original `src/` TypeScript sources are absent.
- A byte-for-byte reconstruction of the editable project is not possible from the archive alone.
- Some recovered files are compiled output, so they should be treated as reference behavior rather than canonical source.
- This package is designed to maximize development context, not to assert that the recovered code is identical to the original authoring tree.
