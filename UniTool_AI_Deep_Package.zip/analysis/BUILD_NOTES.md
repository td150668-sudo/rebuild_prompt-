# Build Notes

The original editable TypeScript sources are not present in the uploaded ZIP, so a true rebuild from source is not possible from this archive alone.

What *is* recoverable:
- Runtime JavaScript under `files/win-x64/`
- Build metadata (`package.json`, `gulpfile.js`, `tsconfig.json`)
- Text-based config and localization content
- Inventory of bundled helper files

Recommended reconstruction path:
1. Use the recovered JS as the runtime reference.
2. Recreate a new `src/` tree progressively.
3. Match the observed server behavior and device adapter behavior.
4. Add tests around the recovered JS behavior.
5. Keep a strict change log so reconstructed modules can be swapped in safely.
