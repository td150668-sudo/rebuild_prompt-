You are continuing development of a recovered Windows iOS debugging/proxy application.

Use the recovered files as the source of truth for observed behavior. Preserve runtime behavior, but rebuild maintainable source code where original sources are missing.

Rules:
- Do not invent unobserved behavior.
- Clearly label inferred behavior.
- Reconstruct modules incrementally.
- Keep a stable file layout.
- Add tests for every recovered behavior you re-implement.
- Prefer small, reversible edits.
- Maintain compatibility with the recovered command-line interface and server endpoints.
