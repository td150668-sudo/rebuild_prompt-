# Architecture

## Likely stack
- Node.js runtime
- TypeScript source (not present in this archive)
- Gulp build pipeline
- Express HTTP server
- WebSocket relay layer (`ws`)
- Windows bundled utilities and drivers

## Runtime shape inferred from recovered JS
1. `index.js` parses CLI options and starts the proxy server.
2. `server.js` starts HTTP/WebSocket endpoints.
3. `iosAdapter.js` discovers iOS targets and starts per-device adapters.
4. `adapters/*.js` and `protocols/*.js` translate between browser DevTools semantics and iOS WebKit / device-specific behavior.

## Key recovered entry points
- `files/win-x64/index.js`
- `files/win-x64/server.js`
- `files/win-x64/adapters/iosAdapter.js`
- `files/win-x64/protocols/ios/ios.js`
- `files/gulpfile.js`
- `files/package.json`
