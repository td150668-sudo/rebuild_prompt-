# Project Summary

**Recovered project name:** RemoteDebug iOS WebKit Adapter  
**Package name:** remotedebug-ios-webkit-adapter  
**Version:** 0.4.2

This archive appears to be a Windows bundle for an iOS webkit debugging/proxy tool with a TypeScript + Gulp Node.js codebase.

## What is present
- A Node.js app package with `gulp`, `typescript`, `express`, `ws`, and related tooling.
- Compiled/transpiled runtime JavaScript under `files/win-x64/`.
- Large collections of platform helpers, drivers, and bundled utilities.
- Configuration and language strings in `lang.json`.

## What is missing
- The original TypeScript source tree (`src/`) is not present in the uploaded archive.
- The build output can be observed, but the original editable source code is not fully recoverable from this archive alone.

## File distribution
- files: 1873
- update: 5

## Extension distribution
- .js: 561
- [noext]: 253
- .md: 226
- .json: 197
- .dll: 177
- .exe: 91
- .ts: 78
- .yml: 43
- .pyc: 29
- .py: 26
- .jst: 25
- .map: 16
- .sys: 15
- .bin: 13
- .txt: 11
- .s: 11

## NPM dependencies declared in package.json
child-process-promise, debug, express, optimist, request, which, ws

## Dev dependencies declared in package.json
@types/express, @types/mocha, @types/optimist, fancy-log, gulp, gulp-mocha, gulp-sourcemaps, gulp-tslint, gulp-typescript, mocha, mock-socket, mockery, tslint, typemoq, typescript

## Notes from recovered files
- `files/gulpfile.js` shows a `gulp build` pipeline compiling `src/**/*.ts` and `test/**/*.ts` into `out/`.
- `files/tsconfig.json` targets CommonJS, ES2016, Node typings, and source maps.
- `files/win-x64/index.js` boots a proxy server on a configurable port.
- `files/win-x64/server.js` creates an HTTP server plus WebSocket server.
- `files/win-x64/adapters/iosAdapter.js` wires device discovery and proxy process management.
